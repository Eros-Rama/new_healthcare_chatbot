# -*- coding: utf-8 -*-

import os

if __name__ == "__main__":
    os.system("python -m rasa_nlu.server --path projects --port 5002")